
var width = 400;
var height = 400;
var margin = {top: 25, left: 100, right: 25, bottom: 25};

var svg = d3.select("#circle-container")
  .append("svg")
  .attr("width",width)
  .attr("height", height);

var circle = svg.append("circle")
  .attr("class","animateCircle")
  .attr("cx", width/2)
  .attr("cy", height/2)
  .attr("fill","#B83564")
  .attr("r", 20);

  //note: will need to add CSS for denoting what circles are, percentages
